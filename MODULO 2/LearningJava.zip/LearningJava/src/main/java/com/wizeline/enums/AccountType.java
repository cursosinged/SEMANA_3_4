/*
 * Copyright (c) 2022 Nextiva, Inc. to Present.
 * All rights reserved.
 */

package com.wizeline.enums;

public enum AccountType {
    NOMINA, AHORRO, PLATINUM
}
